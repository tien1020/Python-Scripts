# -*- coding: utf-8 -*-
from collections import Counter
 
file = open("healthyeating.txt")

file_str = file.read()

#Words:

words = file_str.split()
words_counter = len(words)



#Lines:
lines = file_str.split("\n")

line_counter = 0

for i in lines:
    if i:
        line_counter +=1

#Characters:

characters_counter= len(file_str)

      
#Unique words:     

uniqueWords= set()
for i in lines:
    uniqueWords |= set(i.split())
    
uniqueWords_counter = len(uniqueWords)

#Print:
    
print("lines:", line_counter, ",", "unique:", uniqueWords_counter, ",", "words:", words_counter, ",", "chars:", characters_counter)


    
def count_words(l_words):
    return Counter(l_words)

wc = count_words(words)

print('Most frequent word:',wc.most_common(1))
print('Least frequent word:',wc.most_common()[-1])